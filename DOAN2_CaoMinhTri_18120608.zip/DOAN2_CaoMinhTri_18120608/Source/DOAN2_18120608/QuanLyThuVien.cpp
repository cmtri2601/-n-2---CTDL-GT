﻿#include "QuanLyThuVien.h"

Sach* DocSachFile(ifstream & fin)
{
	char c;
	string _loai;
	string _ma;
	string _ten;
	string _tacgia;
	string _nhasanxuat;
	string ISBN;
	long _giasach;

	Sach* sach;

	//Lấy loại
	while(!fin.eof())
	{
		c = fin.get();
		if (c == '/')
			break;
		_loai += c;
	}
	//Khởi tạo
	if (_loai == "tieng Viet")
		sach = new SachTiengViet;
	else
		sach = new SachNgoaiVan;
	//Lấy mã
	while (!fin.eof())
	{
		c = fin.get();
		if (c == '/')
			break;
		_ma += c;
	}
	sach->set_ma(_ma);
	//Lấy tên
	while (!fin.eof())
	{
		c = fin.get();
		if (c == '/')
			break;
		_ten += c;
	}
	sach->set_ten(_ten);
	//Lấy tác giả
	while (!fin.eof())
	{
		c = fin.get();
		if (c == '/')
			break;
		_tacgia += c;
	}
	sach->set_tacgia(_tacgia);
	//Lấy nhà sản xuất
	while (!fin.eof())
	{
		c = fin.get();
		if (c == '/')
			break;
		_nhasanxuat += c;
	}
	sach->set_nhasanxuat(_nhasanxuat);
	//Lấy giá sách
	fin >> _giasach;
	sach->set_giasach(_giasach);
	//Lấy ISBN
	c = fin.get();
	if (_loai != "tieng Viet")
	{
		while (!fin.eof())
		{
			c = fin.get();
			if (c == '/')
				break;
			ISBN += c;
		}
		sach->set_ISBN(ISBN);
	}
	if (_loai != "tieng Viet")
		c = fin.get();
	return sach;
}

void GhiSachFile(ofstream & fout, Sach* sach)
{
	fout << sach->get_loai() << "/"
		<< sach->get_ma() << "/"
		<< sach->get_ten() << "/"
		<< sach->get_tacgia() << "/"
		<< sach->get_nhasanxuat() << "/"
		<< sach->get_giasach();
	if (sach->get_loai() != "tieng Viet")
		fout << "/" << sach->get_ISBN() << "/";
	fout << "\n";
}

DocGia* DocDocGiaFile(ifstream & fin)
{
	char c;
	string _ma;
	string _hoten;
	string _diachi;
	string _sdt;
	NgayThangNam _ngaysinh;
	int _gioitinh;

	DocGia* docgia = new DocGia;

	//Lấy mã
	while (!fin.eof())
	{
		c = fin.get();
		if (c == '/')
			break;
		_ma += c;
	}
	docgia->set_ma(_ma);
	//Lấy họ tên
	while (!fin.eof())
	{
		c = fin.get();
		if (c == '/')
			break;
		_hoten += c;
	}
	docgia->set_hoten(_hoten);
	//Lấy địa chỉ
	while (!fin.eof())
	{
		c = fin.get();
		if (c == '/')
			break;
		_diachi += c;
	}
	docgia->set_diachi(_diachi);
	//Lấy số điện thoại
	while (!fin.eof())
	{
		c = fin.get();
		if (c == '/')
			break;
		_sdt += c;
	}
	docgia->set_sdt(_sdt);
	//Lấy ngày sinh
	int ngay, thang, nam;
	fin >> ngay;
	c = fin.get();
	fin >> thang;
	c = fin.get();
	fin >> nam;
	c = fin.get();
	_ngaysinh = NgayThangNam(ngay, thang, nam);
	docgia->set_ngaysinh(_ngaysinh);
	//Lấy giới tính
	fin >> _gioitinh;
	c = fin.get();
	docgia->set_gioitinh(_gioitinh);
	
	return docgia;
}

void GhiDocGiaFile(ofstream & fout, DocGia* docgia)
{
	fout << docgia->get_ma() << "/"
		<< docgia->get_hoten() << "/"
		<< docgia->get_diachi() << "/"
		<< docgia->get_sdt() << "/"
		<< docgia->get_ngaysinh() << "/"
		<< docgia->get_gioitinh() << "\n";
}

Phieu * DocPhieuFile(ifstream & fin)
{
	char c;
	string _ma;
	string _masach;
	string _madocgia;
	NgayThangNam _ngaymuon;

	Phieu* phieu = new Phieu;

	//Lấy mã phiếu
	while (!fin.eof())
	{
		c = fin.get();
		if (c == '/')
			break;
		_ma += c;
	}
	phieu->set_ma(_ma);
	//Lấy mã sách
	while (!fin.eof())
	{
		c = fin.get();
		if (c == '/')
			break;
		_masach += c;
	}
	phieu->set_masach(_masach);
	//Lấy mã đôc giả
	while (!fin.eof())
	{
		c = fin.get();
		if (c == '/')
			break;
		_madocgia += c;
	}
	phieu->set_madocgia(_madocgia);
	//Lấy ngày mượn
	int ngay, thang, nam;
	fin >> ngay;
	c = fin.get();
	fin >> thang;
	c = fin.get();
	fin >> nam;
	c = fin.get();
	_ngaymuon = NgayThangNam(ngay, thang, nam);
	phieu->set_ngaymuon(_ngaymuon);

	return phieu;
}

void GhiPhieuFile(ofstream & fout, Phieu * phieu)
{
	fout << phieu->get_ma() << "/"
		<< phieu->get_masach() << "/"
		<< phieu->get_madocgia() << "/"
		<< phieu->get_ngaymuon() << "\n";
}


int ManHinhChinh()
{
	int option;
	cout << "		************        **  **  ** ** ** ** ** ** ** ** ** ** ** **         ************\n";
	cout << "		*******                                                                      *******\n";
	cout << "		**** LAP TRINH HUONG DOI TUONG                                     CAO MINH TRI ****\n";
	cout << "		**** DO AN 2                                                           18120608 ****\n";
	cout << "		***           ======================================================             ***\n";
	cout << "		**                                QUAN LI THU VIEN                                **\n";
	cout << "		**                                                                                **\n";
	cout << "	 	**          I - Sach        |       II - Doc gia      |     Phieu muon/tra        **\n";
	cout << "		**    1.  In danh sach      |  6.  In danh sach       |  11.  In danh sach        **\n";
	cout << "		**    2.  Them              |  7.  Them               |  12.  Them                **\n";
	cout << "		**    3.  Xoa               |  8.  Xoa                |  13.  Xoa                 **\n";
	cout << "		**    4.  Sua               |  9.  Sua                |  14.  Sua                 **\n";
	cout << "		**    5.  Tim               |  10. Tim                |  15.  Tim                 **\n";
	cout << "		**                                                                                **\n";
	cout << "		***     16. Liet ke DG qua han                                                   ***\n";
	cout << "		****    0.  Ket thuc chuong trinh                                               ****\n";
	cout << "		******                                                                        ******\n";
	cout << "		                 ~  Nhap lua chon (0-16): "; cin >> option;
	
	while (option > 16 || option < 0)
	{
		cout << "~  Lua chon khong hop le, nhap lai (0-16): "; cin >> option;
	}
	return option;
}

void Khung()
{
	cout << "		************        **  **  ** ** ** ** ** ** ** ** ** ** ** **         ************\n";
	cout << "		*******                                                                      *******\n";
	cout << "		**** LAP TRINH HUONG DOI TUONG                                     CAO MINH TRI ****\n";
	cout << "		**** DO AN 2                                                           18120608 ****\n";
	cout << "		***           ======================================================             ***\n";
	cout << "		**                                QUAN LI THU VIEN                                **\n";
	cout << "		              ------------------------------------------------------           \n";
}

void Menu()
{
	Thuvien THUVIEN;
	THUVIEN.DocFile();
	
	bool isExit = false;
	int option; //biến lưu lại lựa chọn người dùng
	do
	{
		system("cls");
		option = ManHinhChinh();
		switch (option)
		{
		case 1:
		{
			system("cls");
			Khung();
			cout << " IN DANH SACH \"SACH\" > \n";
			THUVIEN.inds_Sach();
			cout << "\nNhan Enter de thoat!\n"; system("pause");
			break;
		}

		case 2:
		{
			system("cls");
			Khung();
			cout << " THEM SACH > \n";
			THUVIEN.them_Sach();
			cout << "\nNhan Enter de thoat!\n"; system("pause");
			break;
		}

		case 3:
		{
			system("cls");
			Khung();
			cout << " XOA SACH > \n";
			THUVIEN.xoa_Sach();
			cout << "\nNhan Enter de thoat!\n"; system("pause");
			break;
		}

		case 4:
		{
			system("cls");
			Khung();
			cout << " SUA SACH > \n";
			THUVIEN.sua_Sach();
			cout << "\nNhan Enter de thoat!\n"; system("pause");
			break;
		}

		case 5:
		{
			system("cls");
			Khung();
			cout << " TIM SACH > \n";
			THUVIEN.tim_Sach();
			cout << "\nNhan Enter de thoat!\n"; system("pause");
			break;
		}

		case 6:
		{
			system("cls");
			Khung();
			cout << " IN SANH SACH \"DOC GIA\" > \n";
			THUVIEN.inds_DocGia();
			cout << "\nNhan Enter de thoat!\n"; system("pause");
			break;
		}

		case 7:
		{
			system("cls");
			Khung();
			cout << " THEM DOC GIA > \n";
			THUVIEN.them_DocGia();
			cout << "\nNhan Enter de thoat!\n"; system("pause");
			break;
		}

		case 8:
		{
			system("cls");
			Khung();
			cout << " XOA DOC GIA > \n";
			THUVIEN.xoa_DocGia();
			cout << "\nNhan Enter de thoat!\n"; system("pause");
			break;
		}

		case 9:
		{
			system("cls");
			Khung();
			cout << " SUA DOC GIA > \n";
			THUVIEN.sua_DocGia();
			cout << "\nNhan Enter de thoat!\n"; system("pause");
			break;
		}

		case 10:
		{
			system("cls");
			Khung();
			cout << " TIM DOC GIA > \n";
			THUVIEN.tim_DocGia();
			cout << "\nNhan Enter de thoat!\n"; system("pause");
			break;
		}

		case 11:
		{
			system("cls");
			Khung();
			cout << " IN DANH SACH \"PHIEU MUON/TRA\" > \n";
			THUVIEN.inds_Phieu();
			cout << "\nNhan Enter de thoat!\n"; system("pause");
			break;
		}

		case 12:
		{
			system("cls");
			Khung();
			cout << " THEM PHIEU MUON/TRA > \n";
			THUVIEN.them_Phieu();
			cout << "\nNhan Enter de thoat!\n"; system("pause");
			break;
		}

		case 13:
		{
			system("cls");
			Khung();
			cout << " XOA PHIEU MUON/TRA > \n";
			THUVIEN.xoa_Phieu();
			cout << "\nNhan Enter de thoat!\n"; system("pause");
			break;
		}

		case 14:
		{
			system("cls");
			Khung();
			cout << " SUA PHIEU MUON/TRA > \n";
			THUVIEN.sua_Phieu();
			cout << "\nNhan Enter de thoat!\n"; system("pause");
			break;
		}

		case 15:
		{
			system("cls");
			Khung();
			cout << " TIM PHIEU MUON/TRA > \n";
			THUVIEN.tim_Phieu();
			cout << "\nNhan Enter de thoat!\n"; system("pause");
			break;
		}

		case 16:
		{
			system("cls");
			Khung();
			cout << " LIET KE CAC DOC GIA MUON SACH QUA HAN > \n";
			THUVIEN.lietke_dg_quahan();
			cout << "\nNhan Enter de thoat!\n"; system("pause");
			break;
		}

		case 0:
		{
			isExit = true;
			break;
		}
		}
	} while (!isExit);

	THUVIEN.GhiFile();
}
