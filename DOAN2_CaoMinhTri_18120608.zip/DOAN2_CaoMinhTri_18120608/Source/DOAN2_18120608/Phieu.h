#pragma once
#include "DocGia.h"
#include "Sach.h"

class Phieu
{
private:
	string _ma, _masach, _madocgia;
	NgayThangNam _ngaymuon;
public:
	Phieu();
	~Phieu();

	string get_ma();
	string get_masach();
	string get_madocgia();
	NgayThangNam get_ngaymuon();

	void set_ma(string _ma);
	void set_masach(string _masach);
	void set_madocgia(string _madocgia);
	void set_ngaymuon(NgayThangNam _ngaymuon);

	virtual void copy(Phieu* phieu);
	void Nhap();
	void Xuat();
	int SoNgayMuon();
};

