#include "SachNgoaiVan.h"

SachNgoaiVan::SachNgoaiVan() {}
SachNgoaiVan::~SachNgoaiVan() {}

string SachNgoaiVan::get_loai() { return "Ngoai van"; }
string SachNgoaiVan::get_ISBN() { return ISBN; }

void SachNgoaiVan::set_ISBN(string ISBN) { this->ISBN = ISBN; }

void SachNgoaiVan::copy(SachNgoaiVan* sach)
{
	this->Sach::copy(sach);
	this->ISBN = sach->ISBN;
}

void SachNgoaiVan::Nhap()
{
	Sach::Nhap();
	cout << " - Nhap ISBN: "; cin.ignore(); getline(cin, ISBN);
}
void SachNgoaiVan::Xuat()
{
	Sach::Xuat();
}

void SachNgoaiVan::Xuat_don()
{
	cout << " - Loai: " << get_loai() << endl;
	Sach::Xuat_don();
	cout << " - ISBN: " << ISBN << endl;
}
