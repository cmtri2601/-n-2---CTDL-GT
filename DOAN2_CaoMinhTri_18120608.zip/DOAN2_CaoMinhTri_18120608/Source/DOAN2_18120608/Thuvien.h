﻿#pragma once
#include"DocGia.h"
#include"SachTiengViet.h"
#include"SachNgoaiVan.h"
#include"Phieu.h"
#include"QuanLyThuVien.h"
#include<vector>

class Thuvien
{
	vector<Sach*> ds_Sach;
	vector<DocGia*> ds_DocGia;
	vector<Phieu*> ds_Phieu;
public:
	Thuvien();
	~Thuvien();

	//Xử lý dữ liệu với file
	void DocFile_Sach();
	void GhiFile_Sach();
	void DocFile_DocGia();
	void GhiFile_DocGia();
	void DocFile_Phieu();
	void GhiFile_Phieu();

	void DocFile();
	void GhiFile();

	Sach* check_Sach(string ma_S); //Trả về True nếu như đã tồn tại mã đó
	int find_Sach(string ma_S); //Trả về -1 nếu không tìm thấy
	DocGia* check_DocGia(string ma_DG); //Trả về True nếu như đã tồn tại mã đó
	int find_DocGia(string ma_DG); //Trả về -1 nếu không tìm thấy
	Phieu* check_Phieu(string ma_P); //Trả về True nếu như đã tồn tại mã đó
	int inSach_theoTen(string ten_S); //Có một số sách trùng tên, ta dùng hàm này để in ra các sách trùng tên đó
	int inDocGia_theoTen(string ten_S); //Có một số độc giả trùng tên, ta dùng hàm này để in ra các độc giả trùng tên đó

	//Sách
	void inds_Sach();
	void them_Sach();//Nhập sách ở trong hàm
	void xoa_Sach(); //Nhâp mã và tên sau (có thể 1 trong 2)
	void sua_Sach(); //Nhâp mã và tên sau (có thể 1 trong 2)
	void tim_Sach(); //Nhâp mã và tên sau (có thể 1 trong 2)

	//Độc giả
	void inds_DocGia();
	void them_DocGia();//Nhập độc giả ở trong hàm
	void xoa_DocGia(); //Nhâp mã và tên sau (có thể 1 trong 2)
	void sua_DocGia(); //Nhâp mã và tên sau (có thể 1 trong 2)
	void tim_DocGia(); //Nhâp mã và tên sau (có thể 1 trong 2)

	//Phiếu
	void inds_Phieu();
	void them_Phieu(); //Nhập phiếu ở trong hàm
	void xoa_Phieu();  //Nhâp mã và tên sau (có thể 1 trong 2)
	void sua_Phieu();  //Nhâp mã và tên sau (có thể 1 trong 2)
	void tim_Phieu();  //Nhâp mã và tên sau (có thể 1 trong 2)

	//Liệt kê danh sách quá hạn
	void lietke_dg_quahan();
};

