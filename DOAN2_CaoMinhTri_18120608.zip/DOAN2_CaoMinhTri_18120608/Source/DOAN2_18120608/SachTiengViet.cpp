#include "SachTiengViet.h"

SachTiengViet::SachTiengViet() {}
SachTiengViet::~SachTiengViet() {}

string SachTiengViet::get_loai() { return "tieng Viet"; }

string SachTiengViet::get_ISBN()
{
	return string();
}

void SachTiengViet::set_ISBN(string ISBN)
{
}

void SachTiengViet::copy(SachTiengViet* sach)
{
	this->Sach::copy(sach);
}

void SachTiengViet::Nhap()
{
	Sach::Nhap();
}
void SachTiengViet::Xuat()
{
	Sach::Xuat();
}

void SachTiengViet::Xuat_don()
{
	cout << " - Loai: " << get_loai() << endl;
	Sach::Xuat_don();
}
