﻿#pragma once
#include <iostream>
#include <string>
#include <iomanip>
#include "NgayThangNam.h"
using namespace std;

class DocGia
{
private:
	string _ma, _hoten, _diachi, _sdt;
	NgayThangNam _ngaysinh;
	int _gioitinh; // (1)Nam  (2)Nữ
public:
	DocGia();
	~DocGia();

	string get_ma() { return _ma; }
	string get_hoten() { return _hoten; }
	string get_diachi() { return _diachi; }
	string get_sdt() { return _sdt; }
	NgayThangNam get_ngaysinh() { return _ngaysinh; }
	int get_gioitinh() { return _gioitinh; }
	virtual string Loai() { return "Doc gia"; }

	void set_ma(string _ma) { this->_ma = _ma; }
	void set_hoten(string _hoten) { this->_hoten = _hoten; }
	void set_diachi(string _diachi) { this->_diachi = _diachi; }
	void set_sdt(string _sdt) { this->_sdt = _sdt; }
	void set_ngaysinh(NgayThangNam _ngaysinh) { this->_ngaysinh = _ngaysinh; }
	void set_gioitinh(int _gioitinh) { this->_gioitinh = _gioitinh; }

	virtual void copy(DocGia* docgia);
	virtual void Nhap();
	virtual void Xuat();
	virtual void Xuat_don();
};

