#pragma once
#include "Sach.h"
class SachNgoaiVan : public Sach
{
	string ISBN;
public:
	SachNgoaiVan();
	~SachNgoaiVan();

	virtual string get_loai();
	virtual string get_ISBN();

	virtual void set_ISBN(string ISBN);
	
	virtual void copy(SachNgoaiVan* sach);
	virtual void Nhap();
	virtual void Xuat();
	virtual void Xuat_don();
};

