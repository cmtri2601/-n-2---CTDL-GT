#pragma once
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

class Sach
{
protected:
	string _ma, _ten, _tacgia, _nhasanxuat;
	unsigned long _giasach;
public:
	Sach();
	~Sach();

	string get_ma();
	string get_ten();
	string get_tacgia();
	string get_nhasanxuat();
	long get_giasach();
	virtual string get_loai();
	virtual string get_ISBN();

	void set_ma(string _ma);
	void set_ten(string _ten);
	void set_tacgia(string _tacgia);
	void set_nhasanxuat(string _nhasanxuat);
	void set_giasach(long _giasach);
	virtual void set_ISBN(string ISBN);

	virtual void copy(Sach* sach);
	virtual void Nhap();
	virtual void Xuat();
	virtual void Xuat_don();
};


