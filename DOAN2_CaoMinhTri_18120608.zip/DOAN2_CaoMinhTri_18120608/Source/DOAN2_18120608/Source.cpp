#include "QuanLyThuVien.h"

int main()
{
	Menu();
	return 0;
}