﻿#include "Thuvien.h"

Thuvien::Thuvien() {}
Thuvien::~Thuvien() {}

void Thuvien::DocFile_Sach()
{
	ifstream fin("Sach.txt");
	while (!fin.eof())
	{
		Sach* sach = DocSachFile(fin);
		if (sach->get_ma() != string())
		{
			ds_Sach.push_back(sach);
		}
	}
	fin.close();
}

void Thuvien::GhiFile_Sach()
{
	ofstream fout("Sach.txt");
	for (int i = 0; i < ds_Sach.size(); i++)
	{
		GhiSachFile(fout, ds_Sach.at(i));
	}
	fout.close();
}

void Thuvien::DocFile_DocGia()
{
	ifstream fin("DocGia.txt");
	while (!fin.eof())
	{
		DocGia* docgia = DocDocGiaFile(fin);
		if (docgia->get_hoten() != string())
		{
			ds_DocGia.push_back(docgia);
		}
	}
	fin.close();
}

void Thuvien::GhiFile_DocGia()
{
	ofstream fout("DocGia.txt");
	for (int i = 0; i < ds_DocGia.size(); i++)
	{
		GhiDocGiaFile(fout, ds_DocGia.at(i));
	}
	fout.close();
}

void Thuvien::DocFile_Phieu()
{
	ifstream fin("Phieu.txt");
	while (!fin.eof())
	{
		Phieu* phieu = DocPhieuFile(fin);
		if (phieu->get_madocgia() != string())
		{
			ds_Phieu.push_back(phieu);
		}
	}
	fin.close();
}

void Thuvien::GhiFile_Phieu()
{
	ofstream fout("Phieu.txt");
	for (int i = 0; i < ds_Phieu.size(); i++)
	{
		GhiPhieuFile(fout, ds_Phieu.at(i));
	}
	fout.close();
}

void Thuvien::DocFile()
{
	DocFile_Sach();
	DocFile_DocGia();
	DocFile_Phieu();
}

void Thuvien::GhiFile()
{
	GhiFile_Sach();
	GhiFile_DocGia();
	GhiFile_Phieu();
}

Sach* Thuvien::check_Sach(string ma_S)
{
	for (int i = 0; i < ds_Sach.size(); i++)
		if (ma_S == ds_Sach.at(i)->get_ma())
			return ds_Sach.at(i);
	return nullptr;
}

int Thuvien::find_Sach(string ma_S)
{
	for (int i = 0; i < ds_Sach.size(); i++)
		if (ma_S == ds_Sach.at(i)->get_ma())
			return i;
	return -1;
}

DocGia* Thuvien::check_DocGia(string ma_DG)
{
	for (int i = 0; i < ds_DocGia.size(); i++)
		if (ma_DG == ds_DocGia.at(i)->get_ma())
			return ds_DocGia.at(i);
	return nullptr;
}

int Thuvien::find_DocGia(string ma_DG)
{
	for (int i = 0; i < ds_DocGia.size(); i++)
		if (ma_DG == ds_DocGia.at(i)->get_ma())
			return i;
	return -1;
}

Phieu* Thuvien::check_Phieu(string ma_P)
{
	for (int i = 0; i < ds_Phieu.size(); i++)
		if (ma_P == ds_Phieu.at(i)->get_ma())
			return ds_Phieu.at(i);
	return nullptr;
}

int Thuvien::inSach_theoTen(string ten_S)
{
	int soluong = 0;
	for (int i = 0; i < ds_Sach.size(); i++)
		if (ten_S == ds_Sach.at(i)->get_ten())
		{
			soluong++;
		}
	if (soluong == 0)
		cout << "Khong co sach co ten da nhap!\n";
	else
	{
		cout << setw(10) << "Ma" << setw(30) << "Ten" << setw(20) << "Tac gia" << setw(30) << "Nha san xuat" << setw(10) << "Gia sach" << setw(15) << "ISBN" << endl;
		for (int i = 0; i < ds_Sach.size(); i++)
			if (ten_S == ds_Sach.at(i)->get_ten())
			{
				ds_Sach.at(i)->Xuat();
			}
	}
	return soluong;
}

int Thuvien::inDocGia_theoTen(string ten_S)
{
	int soluong = 0;
	for (int i = 0; i < ds_DocGia.size(); i++)
		if (ten_S == ds_DocGia.at(i)->get_hoten())
		{
			soluong++;
		}
	if (soluong == 0)
		cout << "Khong co doc gia co ten da nhap!\n";
	else
	{
		cout << setw(10) << "Ma" << setw(25) << "Ho ten" << setw(30) << "Dia chi" << setw(15) << "So dien thoai" << setw(12) << "Ngay sinh" << setw(16) << "Gioi tinh\n";
		for (int i = 0; i < ds_DocGia.size(); i++)
			if (ten_S == ds_DocGia.at(i)->get_hoten())
			{
				ds_DocGia.at(i)->Xuat();
			}
	}
	return soluong;
}

void Thuvien::inds_Sach()
{
	cout << setw(10) << "Ma" << setw(30) << "Ten" << setw(20) << "Tac gia" << setw(30) << "Nha san xuat" << setw(10) << "Gia sach" << setw(15) << "ISBN" << endl;
	for (int i = 0; i < ds_Sach.size(); i++)
		ds_Sach.at(i)->Xuat();
}

void Thuvien::them_Sach()
{
	char _option;
	Sach* sach;
	cout << "  Cac loai sach: \n";
	cout << "\t1.Sach tieng Viet\n\t2.Sach Ngoai Van\n";
	cout << "   ~ Nhap lua chon: "; cin >> _option;
	if (_option == '1')
	{
		sach = new SachTiengViet();
		sach->Nhap();
		if (check_Sach(sach->get_ma()) == nullptr)
			ds_Sach.push_back(sach);
		else
		{
			cout << " Ma da ton tai!\n";
		}
	}
	else if (_option == '2')
	{
		sach = new SachNgoaiVan();
		sach->Nhap();
		if (check_Sach(sach->get_ma()) == nullptr)
			ds_Sach.push_back(sach);
		else
		{
			cout << "Ma da ton tai!\n";
		}
	}
	else
	{
		cout << "Khong co ton tai lua chon tren!\n";
	}
}

void Thuvien::xoa_Sach()
{
	string ten;
	string ma;

	cout << "* Nhap ten sach: "; cin.ignore(); getline(cin, ten);

	if (inSach_theoTen(ten) != 0)
	{
		cout << "* Nhap ma sach (theo nhung ma o tren): "; cin >> ma;
		if (check_Sach(ma) == nullptr || check_Sach(ma)->get_ten() != ten)
		{
			cout << "Ma va ten khong khop!\n";
		}
		else
		{
			for (vector<Sach*>::iterator it = ds_Sach.begin(); it != ds_Sach.end(); it++)
			{
				if ((*it)->get_ma() == ma)
				{
					ds_Sach.erase(it);
					cout << "Da xoa!\n";
					return;
				}
			}
		}
	}
}

void Thuvien::sua_Sach()
{
	string ten;
	string ma;

	cout << "* Nhap ten sach: "; cin.ignore(); getline(cin, ten);

	if (inSach_theoTen(ten) != 0)
	{
		cout << "* Nhap ma sach (theo nhung ma o tren): "; cin >> ma;
		if (check_Sach(ma) == nullptr || check_Sach(ma)->get_ten() != ten)
		{
			cout << "Ma va ten khong khop!\n";
		}
		else
		{
			for (int i = 0; i < ds_Sach.size(); i++)
			{
				if (ma == ds_Sach.at(i)->get_ma())
				{
					cout << "** Thong tin sach can sua: \n";
					ds_Sach.at(i)->Xuat_don();
					Sach* sach_tam;
					Sach* sach;

					cout << "** Nhap thong tin can sua: \n";
					if (ds_Sach.at(i)->get_loai() == "tieng Viet")
					{
						sach_tam = new SachTiengViet;
						sach_tam->copy(ds_Sach.at(i));
						ds_Sach.at(i)->set_ma(string());

						sach = new SachTiengViet;
						sach->Nhap();
						if (check_Sach(sach->get_ma()) == nullptr)
						{
							ds_Sach.at(i)->copy(sach);
						}
						else
						{
							cout << "Ma da ton tai!\n";
							ds_Sach.at(i)->copy(sach_tam);
						}
					}
					else
					{
						sach_tam = new SachNgoaiVan;
						sach_tam->copy(ds_Sach.at(i));
						ds_Sach.at(i)->set_ma(string());

						sach = new SachNgoaiVan;
						sach->Nhap();
						if (check_Sach(sach->get_ma()) == nullptr)
						{
							ds_Sach.at(i)->copy(sach);
							ds_Sach.at(i)->set_ISBN(sach->get_ISBN());
						}
						else
						{
							cout << "Ma da ton tai!\n";
							ds_Sach.at(i)->copy(sach_tam);
							ds_Sach.at(i)->set_ISBN(sach_tam->get_ISBN());
						}
					}
				}
			}
		}
	}
}

void Thuvien::tim_Sach()
{
	string ten;
	string ma;

	cout << "* Nhap ten sach: "; cin.ignore(); getline(cin, ten);

	if (inSach_theoTen(ten) != 0)
	{
		cout << "* Nhap ma sach (theo nhung ma o tren): "; cin >> ma;
		if (check_Sach(ma) == nullptr || check_Sach(ma)->get_ten() != ten)
		{
			cout << "Ma va ten khong khop!\n";
		}
		else
		{
			for (int i = 0; i < ds_Sach.size(); i++)
			{
				if (ma == ds_Sach.at(i)->get_ma())
				{
					cout << "Thong tin sach can tim: \n";
					ds_Sach.at(i)->Xuat_don();
					return;
				}
			}
		}
	}

}

void Thuvien::inds_DocGia()
{
	cout << setw(10) << "Ma" << setw(25) << "Ho ten" << setw(30) << "Dia chi" << setw(15) << "So dien thoai" << setw(12) << "Ngay sinh" << setw(16) << "Gioi tinh\n";
	for (int i = 0; i < ds_DocGia.size(); i++)
		ds_DocGia.at(i)->Xuat();
}

void Thuvien::them_DocGia()
{
	DocGia* docgia;
	docgia = new DocGia();
	docgia->Nhap();
	if (check_DocGia(docgia->get_ma()) == nullptr)
		ds_DocGia.push_back(docgia);
	else
	{
		cout << "Ma da ton tai!\n";
	}
}

void Thuvien::xoa_DocGia()
{
	string ten;
	string ma;

	cout << "* Nhap ten doc gia: "; cin.ignore(); getline(cin, ten);

	if (inDocGia_theoTen(ten) != 0)
	{
		cout << "* Nhap ma doc gia (theo nhung ma o tren): "; cin >> ma;
		if (check_DocGia(ma) == nullptr || check_DocGia(ma)->get_hoten() != ten)
		{
			cout << "Ma va ten khong khop!\n";
		}
		else
		{
			for (vector<DocGia*>::iterator it = ds_DocGia.begin(); it != ds_DocGia.end(); it++)
			{
				if ((*it)->get_ma() == ma)
				{
					ds_DocGia.erase(it);
					cout << "Da xoa!\n";
					return;
				}
			}
		}
	}
}

void Thuvien::sua_DocGia()
{
	string ten;
	string ma;

	cout << "* Nhap ten doc gia: "; cin.ignore(); getline(cin, ten);

	if (inDocGia_theoTen(ten) != 0)
	{
		cout << "* Nhap ma doc gia (theo nhung ma o tren): "; cin >> ma;
		if (check_DocGia(ma) == nullptr || check_DocGia(ma)->get_hoten() != ten)
		{
			cout << "Ma va ten khong khop!\n";
		}
		else
		{
			for (int i = 0; i < ds_DocGia.size(); i++)
			{
				if (ma == ds_DocGia.at(i)->get_ma())
				{
					cout << "** Thong tin sach can sua: \n";
					ds_DocGia.at(i)->Xuat_don();
					DocGia* docgia_tam;
					DocGia* docgia = new DocGia;

					cout << "** Nhap thong tin can sua: \n";
					docgia_tam = new DocGia;
					docgia_tam->copy(ds_DocGia.at(i));
					ds_DocGia.at(i)->set_ma(string());

					docgia->Nhap();
					if (check_DocGia(docgia->get_ma()) == nullptr)
					{
						ds_DocGia.at(i)->copy(docgia);
					}
					else
					{
						cout << "Ma da ton tai!\n";
						ds_DocGia.at(i)->copy(docgia_tam);
					}
				}
			}
		}
	}
}

void Thuvien::tim_DocGia()
{
	string ten;
	string ma;

	cout << "* Nhap ten doc gia: "; cin.ignore(); getline(cin, ten);

	if (inDocGia_theoTen(ten) != 0)
	{
		cout << "* Nhap ma doc gia (theo nhung ma o tren): "; cin >> ma;
		if (check_DocGia(ma) == nullptr || check_DocGia(ma)->get_hoten() != ten)
		{
			cout << "Ma va ten khong khop!\n";
		}
		else
		{
			for (int i = 0; i < ds_DocGia.size(); i++)
			{
				if (ma == ds_DocGia.at(i)->get_ma())
				{
					cout << "** Thong tin sach can tim: \n";
					ds_DocGia.at(i)->Xuat_don();
					return;
				}
			}
		}
	}
}

void Thuvien::inds_Phieu()
{
	cout << setw(12) << "Ma" << setw(30) << "Sach" << setw(25) << "Doc gia" << setw(15) << "Ngay muon\n";
	for (int i = 0; i < ds_Phieu.size(); i++)
	{
		cout << setw(12) << ds_Phieu.at(i)->get_ma();
		if (check_Sach(ds_Phieu.at(i)->get_masach()) == nullptr)
			cout << setw(30) << "MA KHONG TON TAI!";
		else
			cout << setw(30) << check_Sach(ds_Phieu.at(i)->get_masach())->get_ten();
		if (check_DocGia(ds_Phieu.at(i)->get_madocgia()) == nullptr)
			cout << setw(25) << "MA KHONG TON TAI!";
		else
			cout << setw(25) << check_DocGia(ds_Phieu.at(i)->get_madocgia())->get_hoten();
		cout << setw(6) << ds_Phieu.at(i)->get_ngaymuon() << endl;
	}
}

void Thuvien::them_Phieu()
{
	Phieu* phieu;
	phieu = new Phieu();

	string tenS, tenDG, maS, maDG, ma;

	cout << "* Nhap ten sach: "; cin.ignore(); getline(cin, tenS);
	if (inSach_theoTen(tenS) == 0)
		return;

	cout << "* Nhap ten doc gia: "; getline(cin, tenDG);
	if (inDocGia_theoTen(tenDG) == 0)
		return;

	cout << "\n* Nhap thong tin phieu:\n";
	phieu->Nhap();
	if (check_Phieu(phieu->get_ma()) == nullptr)
		ds_Phieu.push_back(phieu);
	else
	{
		cout << "Ma da ton tai!\n";
	}
}

void Thuvien::xoa_Phieu()
{
	string ma;
	cout << "* Nhap ma phieu muon/tra: "; cin >> ma;

	if (check_Phieu(ma) == nullptr)
	{
		cout << "Ma khong ton tai!\n";
	}
	else
	{
		for (vector<Phieu*>::iterator it = ds_Phieu.begin(); it != ds_Phieu.end(); it++)
		{
			if ((*it)->get_ma() == ma)
			{
				ds_Phieu.erase(it);
				return;
			}
		}
	}
}

void Thuvien::sua_Phieu()
{
	string ma;
	cout << "* Nhap ma phieu muon/tra: "; cin >> ma;

	if (check_Phieu(ma) == nullptr)
	{
		cout << "Ma khong ton tai!\n";
	}
	else
	{
		for (int i = 0; i < ds_Phieu.size(); i++)
		{
			if (ma == ds_Phieu.at(i)->get_ma())
			{
				cout << "** Thong tin phieu muon/tra can sua";
				cout << " - Ma phieu muon/tra: " << ds_Phieu.at(i)->get_ma() << endl;
				cout << " - Ten sach: ";
				if (check_Sach(ds_Phieu.at(i)->get_masach()) == nullptr)
					cout << "MA KHONG TON TAI!\n";
				else
					cout << check_Sach(ds_Phieu.at(i)->get_masach())->get_ten() << endl;
				cout << " - Ten doc gia: ";
				if (check_DocGia(ds_Phieu.at(i)->get_madocgia()) == nullptr)
					cout << "MA KHONG TON TAI!\n";
				else
					cout << check_DocGia(ds_Phieu.at(i)->get_madocgia())->get_hoten() << endl;
				cout << " - Ngay muon: " << ds_Phieu.at(i)->get_ngaymuon() << endl;
			
				cout << "** Nhap thong tin can sua: \n";
				Phieu* phieu_tam;
				Phieu* phieu = new Phieu;
				phieu_tam = new Phieu;
				phieu_tam->copy(ds_Phieu.at(i));
				ds_Phieu.at(i)->set_ma(string());

				phieu->Nhap();
				if (check_Phieu(phieu->get_ma()) == nullptr)
				{
					ds_Phieu.at(i)->copy(phieu);
				}
				else
				{
					cout << "Ma da ton tai!\n";
					ds_Phieu.at(i)->copy(phieu_tam);
					return;
				}
			}
		}
	}
}

void Thuvien::tim_Phieu()
{
	string ma;
	cout << "* Nhap ma phieu muon/tra: "; cin >> ma;

	if (check_Phieu(ma) == nullptr)
	{
		cout << "Ma khong ton tai!\n";
	}
	else
	{
		for (int i = 0; i < ds_Phieu.size(); i++)
		{
			if (ma == ds_Phieu.at(i)->get_ma())
			{
				cout << "** Thong tin phieu muon/tra can tim: \n";
				cout << " - Ma phieu muon/tra: " << ds_Phieu.at(i)->get_ma() << endl;
				cout << " - Ten sach: ";
				if (check_Sach(ds_Phieu.at(i)->get_masach()) == nullptr)
					cout << "MA KHONG TON TAI!\n";
				else
					cout << check_Sach(ds_Phieu.at(i)->get_masach())->get_ten() << endl;
				cout << " - Ten doc gia: ";
				if (check_DocGia(ds_Phieu.at(i)->get_madocgia()) == nullptr)
					cout << "MA KHONG TON TAI!\n";
				else
					cout << check_DocGia(ds_Phieu.at(i)->get_madocgia())->get_hoten() << endl;
				cout << " - Ngay muon: " << ds_Phieu.at(i)->get_ngaymuon() << endl;
				return;
			}
		}
	}
}

void Thuvien::lietke_dg_quahan()
{
	long long* docgia = new long long[ds_DocGia.size()];
	//Khởi tạo
	for (int i = 0; i < ds_DocGia.size(); i++)
	{
		docgia[i] = 0;
	}
	//Tìm kiếm độc giả quá hạn trên phiếu mượn trả
	int soluong = 0;
	for (int i = 0; i < ds_Phieu.size(); i++)
	{
		if (ds_Phieu.at(i)->SoNgayMuon() > 7)
		{
			int vitri_s = find_Sach(ds_Phieu.at(i)->get_masach());
			int vitri_dg = find_DocGia(ds_Phieu.at(i)->get_madocgia());
			if (vitri_s != -1 && vitri_dg != -1)
			{
				if (ds_Sach.at(vitri_s)->get_loai() == "tieng Viet")
					docgia[i] += (ds_Phieu.at(i)->SoNgayMuon() - 7) * 10000;
				else
					docgia[i] += (ds_Phieu.at(i)->SoNgayMuon() - 7) * 20000;
				soluong++;
			}
		}
	}
	//In danh sách
	if (soluong == 0)
		cout << "Khong co doc gia nao muon sach qua han!\n";
	else
	{
		cout << setw(15) << "Ma doc gia" << setw(25) << "Ten doc gia" << setw(20) << "Tien phat\n";
		for (int i = 0; i < ds_DocGia.size(); i++)
		{
			if (docgia[i] > 0)
			{
				cout << setw(15) << ds_DocGia.at(i)->get_ma() << setw(25) << ds_DocGia.at(i)->get_hoten() << setw(20) << docgia[i] << endl;
			}
		}
	}
}

