#pragma once
#include "Thuvien.h"
#include <fstream>

Sach* DocSachFile(ifstream& fin);
void GhiSachFile(ofstream& fout, Sach* sach);
DocGia* DocDocGiaFile(ifstream& fin);
void GhiDocGiaFile(ofstream& fout, DocGia* docgia);
Phieu* DocPhieuFile(ifstream& fin);
void GhiPhieuFile(ofstream& fout, Phieu* phieu);


int ManHinhChinh();
void Khung();
void Menu();