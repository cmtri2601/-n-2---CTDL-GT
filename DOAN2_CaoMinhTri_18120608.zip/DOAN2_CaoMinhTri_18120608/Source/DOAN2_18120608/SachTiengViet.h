#pragma once
#include "Sach.h"
class SachTiengViet: public Sach
{
public:
	SachTiengViet();
	~SachTiengViet();

	virtual string get_loai();
	virtual string get_ISBN();

	virtual void set_ISBN(string ISBN);

	virtual void copy(SachTiengViet* sach);
	virtual void Nhap();
	virtual void Xuat();
	virtual void Xuat_don();
};

