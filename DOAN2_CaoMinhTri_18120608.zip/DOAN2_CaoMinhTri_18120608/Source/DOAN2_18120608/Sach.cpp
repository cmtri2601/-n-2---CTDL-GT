#include "Sach.h"

Sach::Sach() 
{
	this->_ma = string(); 
	this->_ten = string();
	this->_tacgia = string();
	this->_nhasanxuat = string();
	this->_giasach = 0;
}
Sach::~Sach() {}

string Sach::get_ma() { return _ma; }
string Sach::get_ten() { return _ten; }
string Sach::get_tacgia() { return _tacgia; }
string Sach::get_nhasanxuat() { return _nhasanxuat; }
long Sach::get_giasach() { return _giasach; }

string Sach::get_loai()
{
	return "";
}

string Sach::get_ISBN()
{
	return string();
}

void Sach::set_ma(string _ma) { this->_ma = _ma;  }
void Sach::set_ten(string _ten) { this->_ten = _ten; }
void Sach::set_tacgia(string _tacgia) { this->_tacgia = _tacgia; }
void Sach::set_nhasanxuat(string _nhasanxuat) { this->_nhasanxuat = _nhasanxuat; }
void Sach::set_giasach(long _giasach) { this->_giasach = _giasach; }

void Sach::set_ISBN(string ISBN)
{
}



void Sach::copy(Sach * sach)
{
	this->_ma = sach->_ma;
	this->_ten = sach->_ten;
	this->_tacgia = sach->_tacgia;
	this->_nhasanxuat = sach->_nhasanxuat;
	this->_giasach = sach->_giasach;
}

void Sach::Nhap()
{
	cout << " - Nhap ma sach: "; cin.ignore(); getline(cin, _ma);
	cout << " - Nhap ten sach: "; getline(cin, _ten);
	cout << " - Nhap tac gia: "; getline(cin, _tacgia);
	cout << " - Nhap nha san xuat: "; getline(cin, _nhasanxuat);
	cout << " - Nhap gia sach: "; cin >> _giasach;
}
void Sach::Xuat()
{
	cout << setw(10) << _ma << setw(30) << _ten << setw(20) << _tacgia << setw(30) << _nhasanxuat << setw(10) << _giasach;
	if (get_loai() == "Ngoai van")
		cout << setw(15) << get_ISBN();
	cout << endl;
}

void Sach::Xuat_don()
{
	cout << " - Ma sach: " << _ma << endl;
	cout << " - Ten sach: " << _ten << endl;
	cout << " - Tac gia: " << _tacgia << endl;
	cout << " - Nha san xuat: " << _nhasanxuat << endl;
	cout << " - Gia sach: " << _giasach << endl;
}
