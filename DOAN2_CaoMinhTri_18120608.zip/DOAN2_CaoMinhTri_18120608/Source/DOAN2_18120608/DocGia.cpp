#include "DocGia.h"

DocGia::DocGia()
{
	_ma = "00000";
	_hoten = "";
	_diachi = "";
	_sdt = "";
	_ngaysinh = NgayThangNam();
	_gioitinh = 0;
}
DocGia::~DocGia() {}

void DocGia::copy(DocGia* docgia)
{
	this->_ma = docgia->_ma;
	this->_hoten = docgia->_hoten;
	this->_diachi = docgia->_diachi;
	this->_sdt = docgia->_sdt;
	this->_ngaysinh = docgia->_ngaysinh;
	this->_gioitinh = docgia->_gioitinh;
}

void DocGia::Nhap()
{
	cout << " - Nhap ma doc gia: "; cin >> _ma;
	cout << " - Nhap ho ten: "; cin.ignore(); getline(cin, _hoten);
	cout << " - Nhap ma dia chi: "; getline(cin, _diachi);
	cout << " - Nhap so dien thoai: "; getline(cin, _sdt);
	cout << " - Nhap ngay sinh: \n"; cin >> _ngaysinh;
	cout << " - Nhap gioi tinh (1)Nam/(2)Nu: "; cin >> _gioitinh;
}

void DocGia::Xuat()
{
	cout << setw(10) << _ma << setw(25) << _hoten << setw(30) << _diachi << setw(15) << _sdt << setw(5) << _ngaysinh;
	if (_gioitinh == 1)
		cout << setw(15) << "Nam";
	else if (_gioitinh == 2)
		cout << setw(15) << "Nu";
	else 
		cout << setw(15) << "Chua xac dinh";
	cout << endl;
}

void DocGia::Xuat_don()
{
	cout << " - Ma doc gia: " << _ma << endl;
	cout << " - Ho ten: " << _hoten << endl;
	cout << " - Dia chi: " << _diachi << endl;
	cout << " - So dien thoai: " << _sdt << endl;
	cout << " - Ngay sinh: " << _ngaysinh << endl;
	cout << " - Gioi tinh: ";
	if (_gioitinh == 1)
		cout << "Nam\n";
	else if (_gioitinh == 2)
		cout << "Nu\n";
	else
		cout << "Chua xac dinh\n";
}
