#include "Phieu.h"

Phieu::Phieu() {}
Phieu::~Phieu() {}

string Phieu::get_ma() { return _ma; }
string Phieu::get_masach() { return _masach; }
string Phieu::get_madocgia() { return _madocgia; }
NgayThangNam Phieu::get_ngaymuon() { return _ngaymuon; }

void Phieu::set_ma(string _ma) { this->_ma = _ma; }
void Phieu::set_masach(string _masach) { this->_masach = _masach; }
void Phieu::set_madocgia(string _madocgia) { this->_madocgia = _madocgia; }
void Phieu::set_ngaymuon(NgayThangNam _ngaymuon) { this->_ngaymuon = _ngaymuon; }

void Phieu::copy(Phieu * phieu)
{
	this->_ma = phieu->_ma;
	this->_masach = phieu->_masach;
	this->_madocgia = phieu->_madocgia;
	this->_ngaymuon = phieu->_ngaymuon;
}

void Phieu::Nhap()
{
	cout << " - Nhap ma phieu: "; cin >> _ma;
	cout << " - Nhap ma sach: "; cin >> _masach;
	cout << " - Nhap ma doc gia: "; cin >> _madocgia;
	cout << " - Nhap ngay muon: \n"; cin >> _ngaymuon;
}
void Phieu::Xuat()
{

}

int Phieu::SoNgayMuon()
{
	NgayThangNam hientai;
	return hientai - this->_ngaymuon;
}