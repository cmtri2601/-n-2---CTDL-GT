#pragma once
#include<iostream>
#include<ctime>
using namespace std;
class NgayThangNam
{
private:
	int ngay, thang, nam;
public:
	NgayThangNam();
	NgayThangNam(int ngay, int thang, int nam);
	~NgayThangNam(void);
	bool check(const int&, const int&, const int&);
	NgayThangNam operator+(const int&);
	NgayThangNam operator-(const int&);
	long long operator-(const NgayThangNam&);
	friend ostream &operator<<(ostream &out, const NgayThangNam&);
	friend istream &operator>>(istream &in, NgayThangNam &);
};
